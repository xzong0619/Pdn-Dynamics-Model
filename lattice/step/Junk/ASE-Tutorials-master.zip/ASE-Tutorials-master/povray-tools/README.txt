This folder contains files for generating POVRAY pictures using ASE. 
For generating your images it should only be necessary to change the settings in Pictures.py
Works with ase-3.6 and povray-3.6
